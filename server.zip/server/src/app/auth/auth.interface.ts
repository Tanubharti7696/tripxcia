export interface AuthInterface {
    _id: string;
    email: string;
    password: string;
    role: string;
    token: string;
    createdAt: string;
    updatedAt: string;
}
